<html>
<head>
</head>
<body>
<script language="javascript">
<!--
alert("<? include('message.php') ?> ")
//->
</script>
</body>
</html>