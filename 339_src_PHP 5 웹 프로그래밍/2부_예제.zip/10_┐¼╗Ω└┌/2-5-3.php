<?php
    $data1 = $data2 = $data3 = $data4 = $data5 = 65;
    $data6 = 20;

    $data1 = $data1 + $data6;	
    $data2 = $data2 - $data6;	
    $data3 = $data3 * $data6;	
    $data4 = $data4 / $data6;	
    $data5 = $data5 % $data6;	

    echo "<H3>data1 = $data1 <BR><BR>";
    echo "data2 = $data2 <BR><BR>";
    echo "data3 = $data3 <BR><BR>";
    echo "data4 = $data4 <BR><BR>";
    echo "data5 = $data5 <BR><BR>";
?>
