<?
  $a=37;
  $b=3;
  $c=$a+$b;
  $d=$a-$b;
  $e=$a*$b;
  $f=(int)($a/$b);
  $g=$a%$b;

  echo ("$a+$b= $c<br>");
  echo ("$a-$b= $d<br>");
  echo ("$a*$b= $e<br>");
  echo ("$a/$b= $f<br>");
  echo ("$a%$b= $g");
?>
