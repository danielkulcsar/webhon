<?php
	$myData1 = 50 + 70;
	$myData2 = 320 / (10 + 30);
	$myData3 = $myData4 = 50;

	echo "<H4> myData1 = $myData1 <BR><BR>";
	echo "myData2 = $myData2 <BR><BR>";
	echo "myData3 = $myData3 <BR><BR>";
	echo "myData4 = $myData4 <BR><BR> </H4>";
?>
