<?php
   $data2 = 20;

   $data1 = ++$data2;	
   echo "data1 = $data1, data2 = $data2 <BR><BR>";

   $data1 = $data2++;	
   echo "data1 = $data1, data2 = $data2 <BR><BR>";

   $data1 = --$data2;	
   echo "data1 = $data1, data2 = $data2 <BR><BR>";

   $data1 = $data2--;	
  echo "data1 = $data1, data2 = $data2 <BR><BR>";
?>
