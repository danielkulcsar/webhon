<?
echo "<html>";
echo "<head><title>I love PHP</title></head>";
echo "<body>";
//echo "<font size="15" color="blue">I Love PHP</font>";  //��������
echo "<font size='15' color='blue'>I Love PHP</font>";
echo "</body>";
echo "</html>";
?>
