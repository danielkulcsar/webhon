<?
function sum($a,$b)
(
	$sum=$a+$b;
	echo "�� = ".$sum;
)

sum{10,50};
?>
