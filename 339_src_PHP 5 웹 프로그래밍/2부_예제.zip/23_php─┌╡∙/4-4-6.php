<?
$url="http://www.codmedia.com";

echo "I Love PHP";

header("location: $url");
?>
