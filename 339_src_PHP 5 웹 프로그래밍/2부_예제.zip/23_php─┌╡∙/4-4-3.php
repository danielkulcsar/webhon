<?
echo "<html>"
echo "<head><title>I love PHP</title></head>";
?>
