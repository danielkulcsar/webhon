<?
$score=$aaa[10];
$score[0] = 24;
$score[1] = 83;
$score[2] = 92;
$score[3] = 73;
$score[4] = 29;
$score[5] = 76;
$score[6] = 62;
$score[7] = 53;
$score[8] = 98;
$score[9] = 78;
for($count = 0; $count < 10; $count++) 
{
  $sum = $sum + $score[$count];
}
echo $sum
?>

