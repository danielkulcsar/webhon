<?
$flower=array("RED"=>"���","YELLOW"=>"�عٶ��","PURPLE"=>"ƫ��");
echo $flower[2];
while(list($key,$value) = each($flower))
	echo "$key -> $value<br>";
?>
