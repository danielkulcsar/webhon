<?
$array[]=42;
$array[]=73;
$array[]=100;
$array[0]=37;
$array[1]=25;
$fruit["A"]="��";
$fruit["B"]="��";


echo $array[0]."<p>";
echo $array[1]."<p>";
echo $array[2]."<p>";
echo $fruit["A"]."<p>";
echo $fruit["B"]."<p>";

echo count($array);
?>
