<?
$val=log(4);
echo $val."<p>";

$val=log10(10);
echo $val."<p>";
?>
