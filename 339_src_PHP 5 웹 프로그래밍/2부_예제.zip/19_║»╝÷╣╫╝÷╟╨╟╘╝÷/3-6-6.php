<?php
echo sqrt(121) . "<br>"; 
echo sqrt(7) . "<br>"; 
echo round(sqrt(7));
?> 