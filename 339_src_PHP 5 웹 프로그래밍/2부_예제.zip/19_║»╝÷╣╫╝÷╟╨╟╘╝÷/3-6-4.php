<?
$a=37.236;
echo ceil($a) . "<br>" . floor($a) . "<br>" . round($a,1) . "<br>" . round($a,2) ;
?>