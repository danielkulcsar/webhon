<?
$a=8246571512542.1728;
$b=sqrt(-3);

echo number_format($a) . "<br>" ;
echo number_format($a,"2",":",",") . "<br>" ;
echo number_format($a,"3","-",":") . "<br>" ;
?>