<?
$a=2542.178;
$b=sqrt(-3);

echo gettype($a) . "<br>" ;
echo is_float($b) . "<br>" ;
echo intval($a) . "<br>" ;
echo isset($b) . "<br>" ;

?>