<html>
	<head>
	 	<title>PHP Test</title>
	</head>
	<body>
		<? 
		   echo "Hello World 1<p>"; 
 		?>

		<?php 
		   echo "Hello World 2<p>"; 
 		?>

		<script language="php">
		    echo "Hello World 3<p>";
		</script>

		<%
		   echo "Hello World 4";
		%>	
	</body>
</html>
