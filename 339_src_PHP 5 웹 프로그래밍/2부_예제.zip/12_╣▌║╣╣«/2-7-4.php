<?php
    for ($k = 2 ; $k < 10 ; $k++) { 
        for ($x = 1 ; $x < 10 ; $x++) { 
            $j = $x * $k;		
            echo "$k * $x = $j, ";
        }
	  echo "<HR>";
    }
?>
