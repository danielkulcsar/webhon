<?
$sum=0;
for ($i = 0; $i <=10; $i++) {
$sum += $i;
}
echo("For use -> Sum(1 - 10) : $sum");
?>
