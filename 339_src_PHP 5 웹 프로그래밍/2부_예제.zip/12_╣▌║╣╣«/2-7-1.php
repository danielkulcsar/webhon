<?
$num=1;
$sum=0;
while ($num <=10) {
  $sum += $num;
  $num++;
}
echo ("While use -> Sum(1 - 10) : $sum ");
?>
