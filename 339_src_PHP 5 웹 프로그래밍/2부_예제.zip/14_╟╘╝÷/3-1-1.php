<?
function plus($a,$b)
{
  $c=$a+$b;
  echo ($c."<p>");
}

plus(5,10);
plus(5,35);
?>
