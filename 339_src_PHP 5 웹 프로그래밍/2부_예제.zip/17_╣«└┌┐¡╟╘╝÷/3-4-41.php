<?
echo "$_POST[a] <br>";
echo "=================<br>";
$a=nl2br($_POST[a]);
echo "$a";
?>
