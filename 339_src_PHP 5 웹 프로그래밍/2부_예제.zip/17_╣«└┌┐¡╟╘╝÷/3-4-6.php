<?

$a="         http://www.codmedia.com     ";
$b=chop($a);
$c=trim($a);

echo "===$b===<br>";
echo "===$c===";

?>