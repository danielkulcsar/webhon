<?
$n1 = 87.176;
$n2 = 54.315;
$n = $n1 + $n2;
$a = sprintf("\%0.2f", $n);
$b = sprintf("\%0.3f", $n1 - $n2);
echo $a . "<br>" . $b;
?> 