<form method="post" action="3-4-41.php">
<textarea name="a" rows="3" cols="30">
</textarea><br>
<input type="submit" value="������">
</form>
