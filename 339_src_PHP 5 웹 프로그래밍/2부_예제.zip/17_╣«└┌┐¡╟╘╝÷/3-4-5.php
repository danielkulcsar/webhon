<?
$a="asymmetric digital subscriber line";

$b=strtolower($a);
$c=strtoupper($a);
$d=ucfirst($a);
$e=ucwords($a);
echo " $b <br> $c <br> $d <br> $e " ;
?> 
