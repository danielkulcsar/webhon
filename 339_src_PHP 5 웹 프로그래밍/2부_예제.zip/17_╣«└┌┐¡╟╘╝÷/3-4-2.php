<?
$year=date("Y");
$mon=date("m");	
$day=date("j");	
printf("%04d-%02d-%02d", $year, $mon, $day);
?> 
