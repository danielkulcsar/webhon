<?
$a = array('SKT', 'LGT', 'KTF');
$b = implode("*", $a);
echo $b;
?> 
