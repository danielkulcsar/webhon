<form method="post" action="3-2-13.php" enctype="multipart/form-data">

<input type=file name="upload"><br>
<input type="submit" value="����">
 
</form>
