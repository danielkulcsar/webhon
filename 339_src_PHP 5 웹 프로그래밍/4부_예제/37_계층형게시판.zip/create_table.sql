-- // -------------------------------------------------------------
-- ������ �Խ��� ���̺� ���� ����
create table msboard(
	    number int unsigned not null auto_increment primary key,
	    name varchar(12) not null,
	    password varchar(16) not null,
	    email varchar(50) not null,
	    homepage varchar(60) not null,
	    subject varchar(60) not null,
	    memo text not null,
	    count smallint unsigned not null,
	    ip varchar(15) not null,
	    writetime int not null,
	    parentno int(11) not null,
	    replylv varchar(10) not null
	);

-- // -------------------------------------------------------------
-- ȸ�� ���̺� ���� ����
create table member(
	memberid varchar(12) not null,
	membername varchar(12) not null,
	memberpass varchar(12) not null,
	membermail varchar(50) ,
	memberurl varchar(50),
	lastlogin int not null
);