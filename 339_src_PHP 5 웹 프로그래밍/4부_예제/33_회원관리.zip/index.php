<html>
<head>
<title>ȸ�� ����</title>
</head>

<frameset cols="19%,*">
    <frame name="left" src="./left.php">
    <frame name="right" src="right.php">
</frameset>

</html>
