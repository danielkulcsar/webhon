<html>
<head><title>����� ����</title>
</head>

<body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0">

<table border="0" cellpadding="0" cellspacing="0" width="700">
    <tr>
        <td width="700">
            <p>&nbsp;</p>
            <p align="center">�� �� �� �ۼ�</p>

            <form name="frm" action="./insert.php" method="post">
            <table align="center" border="1" cellpadding="3" cellspacing="0" width="650">
                <tr>
                    <td width="132">
                        <p align="right">�ۼ��� &nbsp;:</p>
                    </td>
                    <td width="512">
                        <p>&nbsp;<input type="text" name="irum" size="20"></p>
                    </td>
                </tr>
                <tr>
                    <td width="132">
                        <p align="right">�� &nbsp;&nbsp;�� &nbsp;:</p>
                    </td>
                    <td width="512">
                        <p>&nbsp;<textarea name="content" rows="10" cols="69"></textarea></p>
                    </td>
                </tr>
                <tr>
                    <td width="642" colspan="2">
                        <p align="center">
			<input type="submit" name="smt" value="�ۼ��ϱ�">
			&nbsp;&nbsp;&nbsp;
			<input type="reset" name="rst" value="�ʱ�ȭ"></p>
                    </td>
                </tr>
            </table>
            </form>

            <p>&nbsp;</p>
            <p>&nbsp;</p>
        </td>
    </tr>
</table>
</body>
</html>
