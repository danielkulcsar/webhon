main() {
printf("This is the\nsecond program.\n");
}
